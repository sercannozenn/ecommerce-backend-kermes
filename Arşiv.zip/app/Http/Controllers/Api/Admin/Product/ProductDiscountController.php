<?php

namespace App\Http\Controllers\Api\Admin\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Product\ProductStoreRequest;
use App\Http\Requests\Admin\Product\ProductUpdateRequest;

use App\Models\Product;
use App\Services\BrandServices\BrandService;
use App\Services\CategoryServices\CategoryService;
use App\Services\ProductServices\DiscountService;
use App\Services\ProductServices\ProductService;
use App\Services\TagServices\TagService;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductDiscountController extends Controller
{
    public function __construct(private DiscountService $discountService)
    {
    }
    public function searchTargets(Request $request)
    {
        $request->validate([
                               'type' => 'required|in:product,category,brand,tag,user',
                               'q'    => 'nullable|string|max:255',
                           ]);

        $type = $request->get('type');
        $query = $request->get('q');

        return response()->json($this->discountService->searchTargets($type, $query));
    }
}
