<?php

namespace App\Http\Controllers;

use App\Helpers\ResponseFormatter;

abstract class Controller
{
    use ResponseFormatter;
}
